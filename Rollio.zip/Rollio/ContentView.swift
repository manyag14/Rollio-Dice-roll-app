import SwiftUI

struct ContentView: View {
    @State var val: Int = 1
    var colors:[Color]=[.red,.yellow,.blue,.green,.purple,.orange]
    func rolldice(){
        val=Int.random(in: 1...6)
    }
    var body: some View {
        ZStack{
            colors[val-1]
            pipview(value: val)
        }
        .ignoresSafeArea()
        .onTapGesture {
            rolldice()
        }
    }
}

#Preview {
    ContentView()
}
