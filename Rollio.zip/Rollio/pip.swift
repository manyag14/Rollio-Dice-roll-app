//
//  pip.swift
//  Rollio
//
//  Created by KIET26 on 09/10/26.
//

import SwiftUI

struct pip: View {
    let visible:Bool
    var body: some View {
        Circle()
            .fill(Color.black.opacity(0.6))
            .frame(width: 100,height: 100, alignment: .center)
            .opacity(visible ? 1:0)
            
        
    }
}

#Preview {
    pip(visible: true)
}
