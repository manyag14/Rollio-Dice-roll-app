//
//  pipview.swift
//  Rollio
//
//  Created by KIET26 on 09/10/26.
//

import SwiftUI

struct pipview: View {
    let value:Int
    var arr:[Int]{
        switch value{
        case 1:
            return [5]
        case 2:
            return[1,9]
        case 3:
            return[1,5,9]
        case 4:
            return[1,3,7,9]
        case 5:
            return[1,3,5,7,9]
        case 6:
            return[1,3,4,6,7,9]
        default:
            return[]
        }
    }
    var body: some View {
        Grid(horizontalSpacing:37,verticalSpacing:85)
        {
            GridRow{
                pip(visible: arr.contains(1))
                pip(visible: arr.contains(2))
                pip(visible: arr.contains(3))
            }
            GridRow{
                pip(visible: arr.contains(4))
                pip(visible: arr.contains(5))
                pip(visible: arr.contains(6))
            }
            GridRow{
                pip(visible: arr.contains(7))
                pip(visible: arr.contains(8))
                pip(visible: arr.contains(9))
            }
        }
    }
}

#Preview {
    pipview(value: 6)
}

