import SwiftUI

@main
struct RollioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
